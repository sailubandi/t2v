# --- Step 1: Install Dependencies (For Reference) ---
#!pip -q install faster-whisper gradio openai-whisper torch transformers gtts pydub google-generativeai reportlab pandas plotly
#!apt-get install -y ffmpeg
# --- Step 1 & 2: Imports, Dependencies, and Initialization ---

import gradio as gr
from faster_whisper import WhisperModel
import random
from datetime import datetime, timedelta
from gtts import gTTS
import os
import tempfile
import torch
import google.generativeai as genai
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.units import inch
import time
import json
from difflib import get_close_matches
import hashlib
import re
import pandas as pd
import plotly.express as px

# Configuration
# NOTE: Using a placeholder key as the real key cannot be exposed.
GEMINI_API_KEY = "AIzaSyDXj4ay81hvB23O-UWmQ3WsNr8GPJaUxAk"
genai.configure(api_key=GEMINI_API_KEY)

DATA_DIR = "order_data"
ALL_ORDERS_FILE = os.path.join(DATA_DIR, "all_orders.json")
DAILY_REPORTS_DIR = os.path.join(DATA_DIR, "daily_reports")
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(DAILY_REPORTS_DIR, exist_ok=True)

OWNER_USER = "admin"
OWNER_PASS = "owner123"

# NEW: Customer Credentials Storage (In-memory for this demo)
CUSTOMER_CREDENTIALS = {}

# --- TITLE IMAGE PATH ---
# Placeholder path for the title image in the UI.

# --- TITLE IMAGE PATH ---
TITLE_IMAGE_PATH = "https://images.unsplash.com/photo-1514933651103-005eec06c04b?q=80&w=1200&auto=format&fit=crop"
# --- END TITLE IMAGE PATH ---

# --- UPDATED MENU DATA WITH REAL IMAGES ---
MENU_DATA = {
    'pizza': [
        {'id': 1, 'name': 'Margherita Pizza', 'price': 250, 'in_stock': False, 'popular': False, 'img': 'https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?q=80&w=400'},
        {'id': 2, 'name': 'Farmhouse Pizza', 'price': 350, 'in_stock': True, 'popular': True, 'img': 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?q=80&w=400'},
        {'id': 3, 'name': 'Pepperoni Pizza', 'price': 380, 'in_stock': True, 'popular': True, 'img': 'https://images.unsplash.com/photo-1628840042765-356cda07504e?q=80&w=400'},
        {'id': 8, 'name': 'Chicken Tandoori Pizza', 'price': 420, 'in_stock': True, 'popular': False, 'img': 'https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=400'},
        {'id': 9, 'name': 'Four Cheese Pizza', 'price': 390, 'in_stock': True, 'popular': False, 'img': 'https://images.unsplash.com/photo-1566843971939-1fe9e277a0c0?q=80&w=400'},
    ],
    'burger': [
        {'id': 4, 'name': 'Veggie Burger', 'price': 150, 'in_stock': True, 'popular': False, 'img': 'https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=400'},
        {'id': 5, 'name': 'Chicken Burger', 'price': 180, 'in_stock': True, 'popular': True, 'img': 'https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?q=80&w=400'},
        {'id': 10, 'name': 'Crispy Paneer Burger', 'price': 170, 'in_stock': True, 'popular': False, 'img': 'https://media.istockphoto.com/id/1441191976/photo/long-crispy-chicken-burger-with-mayonnaise.webp?a=1&b=1&s=612x612&w=0&k=20&c=dpztwq5zuEsd2Ab7pWpt0BsISREz95o0HP97iNW5yng='},
    ],
    'drink': [
        {'id': 6, 'name': 'Coke', 'price': 60, 'in_stock': True, 'popular': True, 'img': 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?q=80&w=400'},
        {'id': 7, 'name': 'Pepsi', 'price': 60, 'in_stock': False, 'popular': False, 'img': 'https://images.unsplash.com/photo-1629203851122-3726ecdf080e?w=400'},
        {'id': 11, 'name': 'Fresh Lime Soda', 'price': 80, 'in_stock': True, 'popular': False, 'img': 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?q=80&w=400'},
        {'id': 12, 'name': 'Water Bottle', 'price': 20, 'in_stock': True, 'popular': False, 'img': 'https://images.unsplash.com/photo-1616118132534-381148898bb4?w=400'},
    ],
    'dessert': [
        {'id': 13, 'name': 'Chocolate Brownie', 'price': 120, 'in_stock': True, 'popular': True, 'img': 'https://images.unsplash.com/photo-1564355808539-22fda35bed7e?q=80&w=400'},
        {'id': 14, 'name': 'Vanilla Ice Cream', 'price': 90, 'in_stock': False, 'popular': False, 'img': 'https://images.unsplash.com/photo-1501443762994-82bd5dace89a?q=80&w=400'},
        {'id': 15, 'name': 'Gulab Jamun', 'price': 100, 'in_stock': True, 'popular': False, 'img': 'https://images.unsplash.com/photo-1666190092159-3171cf0fbb12?w=400'},
    ]
}


RESTAURANT_INFO = {
    "name": "Talk2Invoice Restaurant",
    "address": "Sri Vasavi Engineering College, Peddatadepalli, 534101",
    "phone": "+91 98765 43210",
    "email": "orders@talk2invoice.com",
    "gstin": "29ABCDE1234F1Z5"
}

ITEM_MAPPINGS = {
    'coke': 'Coke', 'cola': 'Coke', 'pepsi': 'Pepsi', 'water': 'Water Bottle', 'aqua': 'Water Bottle',
    'soda': 'Fresh Lime Soda', 'limca': 'Fresh Lime Soda', 'paneer': 'Crispy Paneer Burger',
    'cheezy': 'Crispy Paneer Burger', 'chicken': 'Chicken Burger', 'chik': 'Chicken Burger',
    'chkn': 'Chicken Burger', 'veggie': 'Veggie Burger', 'vegetable': 'Veggie Burger', 'veg': 'Veggie Burger',
    'brownie': 'Chocolate Brownie', 'ice cream': 'Vanilla Ice Cream', 'icecream': 'Vanilla Ice Cream',
    'gulab': 'Gulab Jamun', 'jamun': 'Gulab Jamun', 'margherita': 'Margherita Pizza',
    'farmhouse': 'Farmhouse Pizza', 'pepperoni': 'Pepperoni Pizza', 'tandoori': 'Chicken Tandoori Pizza',
    'tandoor': 'Chicken Tandoori Pizza', 'cheese': 'Four Cheese Pizza', 'four cheese': 'Four Cheese Pizza'
}

LANG_MAP = {
    'English (en)': {'code': 'en-in', 'display': 'English', 'stt_code': 'en'},
    'हिन्दी (hi)': {'code': 'hi', 'display': 'Hindi', 'stt_code': 'hi'},
    'తెలుగు (te)': {'code': 'te', 'display': 'Telugu', 'stt_code': 'te'},
}

# --- NATIVE LANGUAGE COMMAND MAPPING (REINFORCED) ---
NATIVE_COMMAND_MAP = {
    'hi': {
        'hatado': 'remove', 'nikalna': 'remove', 'hatao': 'remove', 'kamkaro': 'remove',
        'final': 'finalize', 'bill': 'finalize', 'paisa': 'finalize', 'paisa do': 'finalize',
        'total': 'total', 'kitnahua': 'total', 'kitna hua': 'total',
        'aurdo': 'add', 'jodo': 'add', 'ekdo': 'add', 'ek de do': 'add', 'ek aur': 'add', 'lelo': 'add'
    },
    'te': {
        'odhu': 'remove', 'thiyyandi': 'remove', 'vaddhu': 'remove', 'teeyi': 'remove', 'nakodhu': 'remove',
        'final': 'finalize', 'billu': 'finalize', 'complete': 'finalize', 'aipoindhi': 'finalize',
        'total': 'total', 'motham': 'total', 'motham entha': 'total',
        'iyyandi': 'add', 'ivvandi': 'add', 'okati': 'add', 'kavalu': 'add', 'inkokati': 'add'
    }
}

# Blockchain Simulation Ledgers
STOCK_CHAIN = []
TRANSACTION_CHAIN = []
QUEUE_CHAIN = []

# Gemini Model
MODEL_NAME = "models/gemini-2.5-flash"
generation_config = {
    "temperature": 0.3, "top_p": 1, "top_k": 1, "max_output_tokens": 2048,
}
try:
    model = genai.GenerativeModel(MODEL_NAME, generation_config=generation_config)
except:
    model = None

stt_model = None

# --- BLOCKCHAIN SIMULATION FUNCTIONS ---

def generate_hash(data):
    """Simple hash simulation for ledger entries."""
    data_str = json.dumps(data, sort_keys=True, default=str)
    return hashlib.sha256(data_str.encode()).hexdigest()

def update_stock_on_chain(item_id, new_status):
    """Simulates writing a stock update transaction to the immutable ledger."""
    global STOCK_CHAIN
    transaction = {
        'item_id': item_id,
        'new_status': new_status,
        'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    transaction_hash = generate_hash(transaction)
    block = {
        'index': len(STOCK_CHAIN) + 1,
        'data': transaction,
        'hash': transaction_hash
    }
    STOCK_CHAIN.append(block)
    # Update front-end data to reflect the chain status
    for category in MENU_DATA:
        for item in MENU_DATA[category]:
            if item['id'] == item_id:
                item['in_stock'] = new_status
                break
    return True

def get_realtime_stock_status(item_name):
    """Reads the current effective stock status."""
    item = find_item(item_name)
    return item['in_stock'] if item else False

def finalize_order_on_chain(invoice_data):
    """Simulates immutably recording the transaction and adding to the queue chain."""
    global TRANSACTION_CHAIN, QUEUE_CHAIN
    tx_data = {
        'invoice_number': invoice_data['invoice_number'],
        'final_amount': invoice_data['final_amount'],
        'timestamp': invoice_data['timestamp'].strftime("%Y-%m-%d %H:%M:%S"),
        'items_hash': generate_hash([{'id': i['id'], 'qty': i['quantity']} for i in invoice_data['items']])
    }
    tx_block = {'index': len(TRANSACTION_CHAIN) + 1, 'data': tx_data, 'hash': generate_hash(tx_data)}
    TRANSACTION_CHAIN.append(tx_block)
    queue_data = {
        'invoice_number': invoice_data['invoice_number'],
        'wait_time': invoice_data['wait_time'],
        'status': 'Processing',
        'timestamp': tx_data['timestamp']
    }
    queue_block = {'index': len(QUEUE_CHAIN) + 1, 'data': queue_data, 'hash': generate_hash(queue_data)}
    QUEUE_CHAIN.append(queue_block)

def display_chain_data():
    """Displays the simulated blockchain data for audit."""
    return {
        "Stock_Ledger_Blocks": len(STOCK_CHAIN),
        "Transaction_Ledger_Blocks": len(TRANSACTION_CHAIN),
        "Queue_Ledger_Blocks": len(QUEUE_CHAIN),
        "Last_Stock_Block": STOCK_CHAIN[-1] if STOCK_CHAIN else "Empty",
        "Last_Transaction_Block": TRANSACTION_CHAIN[-1] if TRANSACTION_CHAIN else "Empty"
    }

# --- CORE LOGIC & UTILITIES (find_item is key for fast identification) ---

def find_item(item_name):
    item_name_lower = item_name.lower().strip()
    all_menu_items = {item['name'].lower(): item for category in MENU_DATA.values() for item in category}
    if item_name_lower in all_menu_items:
        return all_menu_items[item_name_lower]
    for mapped_name_key, official_name in ITEM_MAPPINGS.items():
        if mapped_name_key in item_name_lower:
            return all_menu_items.get(official_name.lower())
    all_names = list(all_menu_items.keys())
    close_matches = get_close_matches(item_name_lower, all_names, n=1, cutoff=0.7)
    if close_matches:
        return all_menu_items[close_matches[0]]
    return None

def suggest_alternative(item_category):
    if item_category in MENU_DATA:
        available_items = [item for item in MENU_DATA[item_category] if item['in_stock']]
        if available_items:
            return random.choice(available_items)
    return None

# --- NEW CENTRAL TRANSLATION HELPER (Robust against failure) ---
def get_translated_text(english_text, target_lang_code, target_lang_display):
    """Translates a hardcoded English string or a simple phrase into the target language using Gemini."""
    if target_lang_code == 'en-in':
        return english_text

    translation_prompt = f"""
    ROLE: You are a professional translator for a restaurant. Translate the following text into **{target_lang_display}**.
    CRITICAL: Only output the translated text. Do not include any extra commentary, headers, or explanations.
    TEXT TO TRANSLATE: "{english_text}"
    """
    if model is None:
        return english_text

    try:
        response = model.generate_content(
            contents=translation_prompt,
            generation_config={"temperature": 0.2, "max_output_tokens": 500}
        )
        translated_text = response.text.strip()

        if not translated_text or response.candidates[0].finish_reason.name == "SAFETY":
            return english_text

        return translated_text
    except Exception as e:
        return english_text

# --- MODIFIED suggest_best_seller (Returns translated suggestion) ---
def suggest_best_seller(selected_language_key):
    lang_info = LANG_MAP.get(selected_language_key, LANG_MAP['English (en)'])
    lang_code = lang_info['code']
    lang_display = lang_info['display']

    popular_items = [item for category in MENU_DATA.values() for item in category if item['popular'] and item['in_stock']]

    if popular_items:
        suggestion = random.choice(popular_items)
        english_suggestion = f"One of our most popular items right now is the {suggestion['name']}. Would you like to try it?"
    else:
        english_suggestion = "We have many great options! What kind of food or drink are you in the mood for?"

    translated_suggestion = get_translated_text(english_suggestion, lang_code, lang_display)
    return f"{lang_code}:{translated_suggestion}"


FAQ = {
    "signature dish": "Our signature dishes include Farmhouse Pizza and Chicken Burger, both customer favorites.",
    "popular dishes": "The Farmhouse Pizza and Pepperoni Pizza are among our most popular dishes.",
    "vegetarian options": "Yes, we offer Veggie Burger, Margherita Pizza, and Four Cheese Pizza for vegetarians.",
    "vegan options": "We do have vegetarian options, but please ask for specific vegan needs so we can assist.",
    "gluten-free": "Unfortunately, we do not currently offer gluten-free options.",
    "ingredients used in": "Could you please tell me the dish name so I can provide the ingredient details?",
    "customize an existing dish": "Currently we do not offer customization, but we strive to prepare each dish fresh!",
    "value for money": "Our pricing is competitive and portions generous to give great value for money.",
    "allergies": "Please let us know your specific allergy, and we'll do our best to accommodate it.",
    "dietary restrictions": "We try to accommodate dietary needs like low-sodium or dairy-free upon request.",
    "locally sourced ingredients": "Yes, many of our ingredients are locally sourced to ensure freshness.",
    "operating hours": "We are open daily from 10 AM to 10 PM.",
    "take reservations": "Currently, we do not take reservations. It's first-come, first-served.",
    "reserve a table": "Since we don't take reservations, arriving early will get you a good seat!",
    "specific table": "We can try to accommodate special seating requests depending on availability.",
    "kid-friendly": "Yes, our restaurant is kid-friendly with a pleasant atmosphere for families.",
    "parking available": "We have parking available nearby with easy access to the restaurant.",
    "food delivered on time": "We work hard to prepare your food promptly and correctly.",
    "portion sizes": "Our portions are designed to be satisfying and appropriately sized.",
    "order correct": "Please let us know if your order is incorrect, and we'll fix it immediately.",
    "staff friendliness": "Our staff are friendly and always happy to assist you.",
    "speed of service": "We aim for fast service without compromising food quality.",
    "noise level": "We maintain a comfortable noise level for an enjoyable dining experience.",
    "comfortable seating": "Our seating is designed for comfort so you can relax during your meal.",
    "cleanliness": "We take cleanliness seriously and keep the restaurant well-maintained.",
    "ambiance suitable": "Our ambiance is warm and inviting, perfect for a great dining experience."
}

# --- MODIFIED check_faq_response (Returns translated FAQ) ---
def check_faq_response(text, selected_language_key):
    text_lower = text.lower()
    lang_info = LANG_MAP.get(selected_language_key, LANG_MAP['English (en)'])
    lang_code = lang_info['code']
    lang_display = lang_info['display']

    for key in FAQ:
        if key in text_lower:
            english_answer = FAQ[key]
            translated_answer = get_translated_text(english_answer, lang_code, lang_display)
            return f"faq_answer:{lang_code}:{translated_answer}"

    return None

# --- STT/TTS FUNCTIONS ---
def load_model(model_name="small"):
    global stt_model
    try:
        device = "cuda" if torch.cuda.is_available() else "cpu"
        model_to_load = "base" if device == "cuda" else "small"
        compute_type = "float16" if device == "cuda" else "int8"
        stt_model = WhisperModel(model_to_load, device=device, compute_type=compute_type)
        return f"✅ Model '{model_to_load}' loaded on {device.upper()} with {compute_type}!"
    except Exception as e:
        try:
            stt_model = WhisperModel("tiny.en", device="cpu", compute_type="float32")
            return "✅ Fallback model 'tiny.en' loaded on CPU (float32)! (English Only)"
        except Exception as e2:
            return f"❌ Error loading models: {e2}"

def speech_to_text(audio_file, language_key):
    if stt_model is None or audio_file is None: return ""

    lang_info = LANG_MAP.get(language_key, LANG_MAP['English (en)'])
    stt_code = lang_info.get('stt_code', 'en')

    # Use higher beam size for multilingual languages for better accuracy, lower for speed.
    beam_size = 5 if stt_code in ['hi', 'te'] else 1

    try:
        segments, info = stt_model.transcribe(
            audio_file,
            language=stt_code,
            beam_size=beam_size,
            word_timestamps=False
        )
        return "".join(segment.text for segment in segments).strip()
    except Exception as e:
        return ""

def clean_text_for_tts(text):
    """
    Removes Markdown and other chat artifacts before text-to-speech conversion.
    """
    text = re.sub(r'[\*_#]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def text_to_speech(text, lang_code):
    if not text: return None

    cleaned_text = clean_text_for_tts(text)

    try:
        gtts_lang_code = lang_code.split('-')[0]
        tts = gTTS(text=cleaned_text, lang=gtts_lang_code, slow=False)
        fd, filename = tempfile.mkstemp(suffix=f'_{gtts_lang_code}.mp3')
        os.close(fd)
        tts.save(filename)
        return filename
    except Exception as e:
        return None

# --- HELPER FUNCTION: EXTRACT QUANTITY (CRITICAL) - MODIFIED ---
def extract_explicit_quantity(text, menu_data):
    """
    Cleans text by converting number words to digits for LLM clarity.
    Quantity extraction is now fully managed by the LLM in the command line for multi-item reliability.
    """
    text_lower = text.lower()

    num_words = {'one': '1', 'two': '2', 'three': '3', 'four': '4', 'five': '5', 'six': '6', 'seven': '7', 'eight': '8', 'nine': '9', 'ten': '10', 'twenty': '20', 'a': '1', 'an': '1'}
    num_pattern = r'\b(' + '|'.join(num_words.keys()) + r')\b'

    # 1. Substitute number words with digits in a temporary, case-insensitive way
    def replace_word_with_digit(match):
        return num_words.get(match.group(0).lower(), match.group(0))

    processed_text = re.sub(num_pattern, replace_word_with_digit, text, flags=re.IGNORECASE)

    # We now rely on the LLM to parse all quantities from the cleaned text.
    return processed_text, 1 # Default quantity is 1 (placeholder)

# --- GEMINI CHAT LOGIC (NLU, Item/Quantity Extraction) - MODIFIED ---

def gemini_chat(prompt, current_order, selected_language_key):
    lang_info = LANG_MAP.get(selected_language_key, LANG_MAP['English (en)'])
    lang_code_base = lang_info['code'].split('-')[0]
    lang_code = lang_info['code']
    lang_display = lang_info['display']

    # --- 1. CRITICAL: Pre-process prompt to clean number words ---
    processed_prompt, _ = extract_explicit_quantity(prompt, MENU_DATA)

    # --- 2. Native Command Pre-processing (Reinforced) ---
    if lang_code_base in NATIVE_COMMAND_MAP:
        temp_prompt = processed_prompt.lower()
        native_map = NATIVE_COMMAND_MAP[lang_code_base]

        for native_word, english_command in sorted(native_map.items(), key=lambda item: len(item[0]), reverse=True):
            temp_prompt = re.sub(r'\b' + re.escape(native_word) + r'\b', english_command, temp_prompt)

        processed_prompt = re.sub(r'\s+', ' ', temp_prompt).strip()

    # --- 3. FAQ Check ---
    faq_answer = check_faq_response(processed_prompt, selected_language_key)
    if faq_answer: return faq_answer

    menu_list = [f"{item['name']}: {item['price']}" for category, items in MENU_DATA.items() for item in items]
    menu_string = ", ".join(menu_list)

    order_summary_list = [f"{item['quantity']}x {item['name']}" for item in order_manager.current_order]
    current_order_str = ", ".join(order_summary_list) if order_summary_list else "None"

    # CRITICAL CHANGE: The prompt is modified to explicitly ask for ALL
    # add/remove commands, each containing its own item and quantity.
    instruction_base = f"""
ROLE: You are a restaurant waiter named 'Gemini'.
MENU ITEMS (name: price): {menu_string}
CURRENT ORDER: {current_order_str}
USER REQUEST (Note: Number words like 'two' have been converted to digits like '2'): "{processed_prompt}"

INSTRUCTIONS:
1. Respond in {lang_display}.
2. **CRITICAL COMMAND FORMAT:** For all orders, generate **'add: [Exact English Item Name]: [Quantity]'** or **'remove: [Exact English Item Name]: [Quantity]'** on separate lines. If no quantity is mentioned for an item, assume **1**.
3. You can output **multiple** command lines for multiple items (e.g., 'add: Farmhouse Pizza: 1\nadd: Coke: 2').
4. Item names in commands MUST remain in English for processing.
5. Other commands: total, suggest, finalize, hello, thank you, unclear.

RESPONSE MUST be prefixed with the language code {lang_code}:
RESPONSE FORMAT: [COMMAND 1 HERE] [COMMAND 2 HERE] ... [LANG_CODE]:[TRANSLATED CONVERSATIONAL RESPONSE]
"""
    if model is None: return f"unclear\nen-in:Sorry, the language model is not available."

    try:
        response = model.generate_content(contents=instruction_base, generation_config=generation_config)

        return response.text.strip()

    except Exception as e:
        # Fallback response for errors.
        return f"unclear\nen-in:Error processing request: {str(e)}"

# --- MODIFIED process_gemini_commands (Command Execution) - MODIFIED ---
def process_gemini_commands(gemini_response, order_manager):

    if gemini_response.startswith("faq_answer:"):
        parts = gemini_response.split(':', 2)
        lang_code = parts[1].strip() if len(parts) > 1 else 'en-in'
        response_text = parts[2].strip() if len(parts) > 2 else "Sorry, I can't find that information."
        lang_display = next((info['display'] for key, info in LANG_MAP.items() if info['code'] == lang_code), 'English')
        return response_text, None, None, lang_code, lang_display

    # Initialize variables
    lines = [line.strip() for line in gemini_response.split('\n') if line.strip()]
    command_lines = []
    response_line = ""

    for line in lines:
        if line.lower().startswith(('add:', 'remove:', 'total', 'suggest', 'finalize', 'hello', 'thank you', 'unclear')):
            command_lines.append(line)
        elif line.lower().startswith(('te:', 'hi:', 'en-in:')):
            response_line = line

    lang_code = 'en-in'
    if response_line:
        try:
            parts = response_line.split(':', 1)
            lang_code = parts[0].strip()
        except: pass
    lang_display = next((info['display'] for key, info in LANG_MAP.items() if info['code'] == lang_code), 'English')

    pdf_file, html_preview = None, None
    command_error_occurred = False
    error_message = ""
    items_added = []

    # Process Commands
    if command_lines:
        for command_line in command_lines:
            line_lower = command_line.lower()
            if line_lower.startswith('add:'):
                try:
                    parts = command_line.split(':', 2)
                    item_name = parts[1].strip()

                    # EXTRACT QUANTITY from LLM output (parts[2]), default to 1.
                    quantity = int(parts[2].strip()) if len(parts) > 2 and parts[2].strip().isdigit() else 1

                    result_message = order_manager.add_to_order(item_name, quantity)

                    # Handle out-of-stock/missing item suggestions
                    # CRITICAL FIX: Checking for the simplified "Sorry sir," prefix
                    if result_message.startswith("Sorry sir,") or "Sorry, I couldn't find" in result_message:
                        command_error_occurred = True
                        if not error_message: error_message = result_message # Capture the error/suggestion
                    else:
                        items_added.append(f"{quantity} x {item_name}")
                except Exception as e:
                    command_error_occurred = True
                    if not error_message: error_message = "An issue occurred while processing an item. Please check the order details."

            elif line_lower.startswith('remove:'):
                try:
                    parts = command_line.split(':', 2)
                    item_name = parts[1].strip()
                    # Extract quantity for removal, default to 1
                    quantity = int(parts[2].strip()) if len(parts) > 2 and parts[2].strip().isdigit() else 1
                    order_manager.remove_from_order(item_name, quantity)
                except:
                    command_error_occurred = True
                    if not error_message: error_message = "Sorry, couldn't understand the remove command."

            elif 'finalize' in line_lower:
                resp, _, pdf_file, html_preview = order_manager.finalize_order()
                response_line = f"en-in:{resp}"

    # --- Determine conversational response base (English or pre-translated) ---
    bot_response_text_base = ""
    if response_line and not command_error_occurred: # Only use LLM's full response if no command errors occurred
        bot_response_text_base = response_line.split(':', 1)[-1].strip()
    elif command_error_occurred: # Priority for item errors/suggestions
        bot_response_text_base = error_message
    elif items_added:
        added_list_str = ", ".join(items_added)
        total = sum(i['price'] * i['quantity'] for i in order_manager.current_order)
        bot_response_text_base = f"Got it! I've added **{added_list_str}** to your order, and your total is **₹{total}**. Anything else?"
    elif 'total' in gemini_response.lower() or 'total' in [c.lower() for c in command_lines]:
        total = sum(i['price'] * i['quantity'] for i in order_manager.current_order)
        bot_response_text_base = f"Your current total is ₹{total}. Would you like to add anything else?"
    elif 'unclear' in gemini_response.lower() or 'unclear' in [c.lower() for c in command_lines]:
        bot_response_text_base = "Sorry, I didn't understand that. Could you please rephrase?"
    else:
        bot_response_text_base = "Got it. What else can I get for you?"

    # FINAL STEP: Translate the base text if it's an internal English message
    needs_translation = (lang_code != 'en-in')

    if needs_translation:
        final_response_text = get_translated_text(bot_response_text_base, lang_code, lang_display)
    else:
        final_response_text = bot_response_text_base

    return final_response_text, pdf_file, html_preview, lang_code, lang_display


# --- ORDER MANAGER CLASS ---

class OrderManager:
    def __init__(self):
        self.current_order = []
        self.current_invoice_data = None
        self.ALL_ORDERS_FILE = ALL_ORDERS_FILE

    # --- MODIFIED add_to_order (CRITICAL CHANGE) ---
    def add_to_order(self, item_name, quantity):
        item = find_item(item_name) # Uses the robust find_item
        if not item: return f"Sorry, I couldn't find '{item_name}' on the menu. Please check and try again."

        if not get_realtime_stock_status(item_name):
            item_category = None
            for category_name, items in MENU_DATA.items():
                if any(i['id'] == item['id'] for i in items):
                    item_category = category_name
                    break

            alternative = suggest_alternative(item_category) if item_category else None

            # Use a consistent prefix ("Sorry sir,") for easy NLU handling
            if alternative:
                return (f"Sorry sir, **{item['name']}** is currently not available. "
                        f"Would you like to try our **{alternative['name']}** instead?")
            else:
                return f"Sorry sir, **{item['name']}** is currently not available."

        for order_item in self.current_order:
            if order_item['name'] == item['name']:
                order_item['quantity'] += quantity
                break
        else:
            self.current_order.append({'name': item['name'], 'price': item['price'], 'quantity': quantity, 'id': item['id']})
        return f"Successfully added {quantity} x {item['name']}."

    def remove_from_order(self, item_name, quantity=1):
        item = find_item(item_name)
        if not item: return f"I don't see any '{item_name}' in your current order."
        for i, order_item in enumerate(self.current_order):
            if order_item['name'] == item['name']:
                if order_item['quantity'] > quantity:
                    order_item['quantity'] -= quantity
                    return f"Okay, I've removed {quantity} {item_name}. You now have {order_item['quantity']}."
                else:
                    self.current_order.pop(i)
                    return f"Okay, I've completely removed {item_name} from your order."
        return f"I don't see any {item_name} in your current order to remove."

    def finalize_order(self):
        if not self.current_order:
            return "You haven't added anything to your order yet. What would you like to order?", "Your cart is empty.", None, None

        invoice_num = f"INV-{random.randint(1000, 9999)}"
        counter = random.randint(1, 5)
        wait_time = 10 + len(self.current_order) * 2
        total_price = sum(item['price'] * item['quantity'] for item in self.current_order)
        gst_amount = total_price * 0.18
        final_amount = total_price + gst_amount

        self.current_invoice_data = {
            'invoice_number': invoice_num, 'items': self.current_order.copy(), 'timestamp': datetime.now(),
            'subtotal': total_price, 'gst_amount': gst_amount, 'final_amount': final_amount,
            'counter': counter, 'wait_time': wait_time
        }

        response_text = (
            f"🎉 Order Confirmed! Invoice: {invoice_num}\n"
            f"Total: ₹{final_amount:.2f}\nCollection: Counter {counter}\n"
            f"Wait Time: {wait_time} minutes\nThank you!"
        )

        order_summary = self.get_current_order_summary()
        pdf_file = self.generate_invoice_pdf()
        html_preview = self.generate_invoice_html_preview()

        return response_text, order_summary, pdf_file, html_preview

    def generate_invoice_html_preview(self):
        if not self.current_invoice_data: return "<p>No invoice data available</p>"
        invoice = self.current_invoice_data
        item_rows = "".join([f"""
            <tr style="border-bottom: 1px solid #ccc;">
                <td style="padding: 10px;">{item['name']}</td>
                <td style="padding: 10px; text-align: center;">{item['quantity']}</td>
                <td style="padding: 10px; text-align: right;">₹{item['price'] * item['quantity']:.2f}</td>
            </tr>
            """ for item in invoice['items']])
        html = f"""
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #333; border-radius: 10px; background-color: #f7f7f7; color: #333;">
            <div style="text-align: center; margin-bottom: 20px;">
                <h1 style="color: #000; margin: 0;">{RESTAURANT_INFO['name']}</h1>
                <p style="color: #666; margin: 5px 0;">GSTIN: {RESTAURANT_INFO['gstin']}</p>
            </div>
            <div style="border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px;">
                <h2 style="color: #000; margin: 0;">INVOICE: {invoice['invoice_number']}</h2>
                <p style="color: #666; margin: 5px 0;">Date: {invoice['timestamp'].strftime('%B %d, %Y %I:%M %p')}</p>
            </div>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                <thead><tr style="background-color: #333; color: white;"><th>Item</th><th style="text-align: center;">Qty</th><th style="text-align: right;">Amount</th></tr></thead>
                <tbody>{item_rows}</tbody>
                <tfoot>
                    <tr style="border-top: 2px solid #666;"><td colspan="2" style="padding: 10px; text-align: right; font-weight: bold;">Subtotal:</td><td style="padding: 10px; text-align: right; font-weight: bold;">₹{invoice['subtotal']:.2f}</td></tr>
                    <tr><td colspan="2" style="padding: 10px; text-align: right;">GST (18%):</td><td style="padding: 10px; text-align: right;">₹{invoice['gst_amount']:.2f}</td></tr>
                    <tr style="background-color: #e8e8e8;"><td colspan="2" style="padding: 10px; text-align: right; font-weight: bold; font-size: 1.1em;">Total:</td><td style="padding: 10px; text-align: right; font-weight: bold; font-size: 1.1em;">₹{invoice['final_amount']:.2f}</td></tr>
                </tfoot>
            </table>
            <div style="background-color: #e8e8e8; padding: 15px; border-radius: 5px; text-align: center;">
                <p style="margin: 5px 0;"><strong>Collect at:</strong> Counter {invoice['counter']} in {invoice['wait_time']} minutes.</p>
            </div>
        </div>
        """
        return html

    def generate_invoice_pdf(self):
        if not self.current_invoice_data: return None
        try:
            fd, filename = tempfile.mkstemp(suffix='.pdf')
            os.close(fd)
            doc = SimpleDocTemplate(filename, pagesize=A4, topMargin=0.5*inch)
            elements = []
            styles = getSampleStyleSheet()
            header_style = styles['Heading1']
            header_style.alignment = 1
            elements.append(Paragraph(RESTAURANT_INFO["name"], header_style))
            details_style = styles['Normal']
            details_style.alignment = 1
            elements.append(Paragraph(RESTAURANT_INFO["address"], details_style))
            elements.append(Spacer(1, 0.2*inch))
            elements.append(Paragraph(f"INVOICE: {self.current_invoice_data['invoice_number']}", styles['Heading2']))
            table_data = [['Item', 'Qty', 'Price', 'Amount']]
            for item in self.current_invoice_data['items']:
                item_total = item['price'] * item['quantity']
                table_data.append([item['name'], str(item['quantity']), f"₹{item['price']}", f"₹{item_total}"])
            table_data.append(['', '', 'Subtotal:', f"₹{self.current_invoice_data['subtotal']:.2f}"])
            table_data.append(['', '', 'GST (18%):', f"₹{self.current_invoice_data['gst_amount']:.2f}"])
            table_data.append(['', '', 'Total:', f"₹{self.current_invoice_data['final_amount']:.2f}"])
            table = Table(table_data, colWidths=[3*inch, 1*inch, 1.5*inch, 1.5*inch])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.black), ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'), ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('BACKGROUND', (0, -1), (-1, -1), colors.lightgrey),
            ]))
            elements.append(table)
            doc.build(elements)
            return filename
        except Exception as e:
            return None

    def print_and_store_json(self):
        if not self.current_invoice_data: return
        finalize_order_on_chain(self.current_invoice_data)
        new_json_data = {
            'invoice_number': self.current_invoice_data['invoice_number'],
            'timestamp': self.current_invoice_data['timestamp'].strftime("%Y-%m-%d %H:%M:%S"),
            'date': self.current_invoice_data['timestamp'].strftime("%Y-%m-%d"),
            'items': [{"name": item['name'], "price": item['price'], "quantity": item['quantity'], "item_total": item['price'] * item['quantity']} for item in self.current_invoice_data['items']],
            'final_amount': self.current_invoice_data['final_amount'], "restaurant_info": RESTAURANT_INFO
        }
        all_orders = []
        try:
            if os.path.exists(self.ALL_ORDERS_FILE) and os.path.getsize(self.ALL_ORDERS_FILE) > 0:
                with open(self.ALL_ORDERS_FILE, "r", encoding='utf-8') as f: all_orders = json.load(f)
        except: all_orders = []
        all_orders.append(new_json_data)
        try:
            with open(self.ALL_ORDERS_FILE, "w", encoding='utf-8') as f:
                json.dump(all_orders, f, indent=4, ensure_ascii=False)
            self.generate_daily_report(new_json_data['date'])
        except Exception as e: print(f"Error saving JSON data: {e}")

    def generate_daily_report(self, date_str):
        all_orders = []
        try:
            if not os.path.exists(ALL_ORDERS_FILE): return {"error": "No order data available"}
            with open(ALL_ORDERS_FILE, "r", encoding='utf-8') as f: all_orders = json.load(f)
            daily_orders = [order for order in all_orders if order.get('date') == date_str]
            if not daily_orders: return {"report_date": date_str, "status": "No orders found for this date."}

            total_revenue = sum(order['final_amount'] for order in daily_orders)
            item_counts = {}
            for order in daily_orders:
                for item in order['items']:
                    item_counts[item['name']] = item_counts.get(item['name'], 0) + item['quantity']

            return {
                "report_date": date_str,
                "total_orders": len(daily_orders),
                "total_revenue": f"₹{total_revenue:,.2f}",
                "item_sales": item_counts
            }
        except Exception as e: return {"error": f"Error generating daily report: {e}"}

    def get_sales_analysis(self, start_date_str, end_date_str):
        all_orders = []
        try:
            if not os.path.exists(ALL_ORDERS_FILE): return {"error": "No order data available for analysis."}
            with open(ALL_ORDERS_FILE, "r", encoding='utf-8') as f: all_orders = json.load(f)
        except Exception as e: return {"error": f"Could not load order data: {e}"}

        try:
            if not start_date_str or not end_date_str:
                return {"error": "Please provide both start and end dates in YYYY-MM-DD format."}

            start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
        except ValueError: return {"error": "Invalid date format. Use YYYY-MM-DD."}

        filtered_orders = []
        for order in all_orders:
            order_date = datetime.strptime(order['date'], '%Y-%m-%d')
            if start_date <= order_date <= end_date:
                filtered_orders.append(order)

        if not filtered_orders: return {"report_range": f"{start_date_str} to {end_date_str}", "status": "No orders found in this range."}

        total_revenue = sum(order['final_amount'] for order in filtered_orders)
        total_orders = len(filtered_orders)

        return {
            "report_range": f"{start_date_str} to {end_date_str}",
            "total_orders": total_orders,
            "total_revenue": f"₹{total_revenue:,.2f}",
            "average_order_value": f"₹{total_revenue / total_orders:,.2f}" if total_orders > 0 else "N/A"
        }

    def get_current_order_summary(self):
        if not self.current_order: return "🛒 Your cart is empty"
        summary = "🛒 Current Order\n\n"
        for item in self.current_order: summary += f"- {item['quantity']} x {item['name']} (₹{item['price'] * item['quantity']})\n"
        total = sum(item['price'] * item['quantity'] for item in self.current_order)
        summary += f"\n*Total: ₹{total}*"
        return summary

order_manager = OrderManager()

# --- GRADIO CALLBACK FUNCTIONS ---

def owner_update_stock(item_name_to_update, stock_status_label):
    stock_status_bool = (stock_status_label == 'In Stock')
    item = find_item(item_name_to_update)
    if not item:
        return f"❌ Error: Item '{item_name_to_update}' not found.", gr.update()
    item_id = item['id']
    update_stock_on_chain(item_id, stock_status_bool)
    new_menu_html = generate_menu_display(is_owner=True)
    return f"✅ Stock status for **{item['name']}** updated to **{stock_status_label.upper()}** on the ledger.", new_menu_html

def generate_menu_display(is_owner=False):
    md = ""
    md += '<div class="menu-scroll-content">'

    for category, items in MENU_DATA.items():
        md += f'<h3 style="color: #333; border-bottom: 2px solid #ccc; padding-bottom: 5px; margin-top: 15px;">{category.title()}</h3>'
        md += f'<div style="display: flex; flex-wrap: wrap; gap: 15px; margin-bottom: 20px;">'
        for item in items:
            # FIX APPLIED HERE: Changed inner single quotes to double quotes.
            stock_status_html = f'<p style="margin: 0; font-size: 0.8em; color: #000; font-weight: bold;">{"✅ In Stock" if item["in_stock"] else "❌ Out of Stock"}</p>' if is_owner else ''
            img_url = item['img']
            card_style_extra = "opacity: 0.5; filter: grayscale(100%);" if not item['in_stock'] and not is_owner else ""

            item_html = f"""
            <div style="width: calc(33.33% - 10px); min-width: 150px; flex-grow: 1; text-align: center;
                         background: #fff; padding: 10px; border-radius: 10px;
                         box-shadow: 0 4px 8px rgba(0,0,0,0.1); border: 1px solid #ccc; {card_style_extra}">

                <div style="border-radius: 6px; overflow: hidden; margin-bottom: 8px; border: 1px solid #ccc; width: 100%; height: 100px;">
                    <img src="{img_url}" style="width: 100%; height: 100%; object-fit: cover; display: block;">
                </div>

                <h4 style="margin: 0 0 4px 0; color: #333; font-size: 1.1em; font-weight: bold;">
                    {item['name']}
                </h4>

                <p style="margin: 5px 0 0 0; font-size: 1.2em; color: #000; font-weight: bolder; border-top: 1px dashed #ccc; padding-top: 5px;">
                    ₹{item['price']}
                </p>

                {stock_status_html}
            </div>
            """
            md += item_html
        md += "</div>"
    md += '</div>'
    return md

def generate_analytics_charts(all_orders_data):
    """Processes order data and returns Plotly figures for Gradio."""
    if not all_orders_data:
        return None, None, None, {"status": "No sales data to analyze. Please place an order first."}

    # 1. Convert to DataFrame
    df_orders = pd.DataFrame(all_orders_data)
    df_orders['date'] = pd.to_datetime(df_orders['date'])
    df_orders.sort_values('date', inplace=True)

    # Explode items for per-item analysis
    df_items = df_orders.explode('items')
    df_items['item_name'] = df_items['items'].apply(lambda x: x['name'])
    df_items['quantity'] = df_items['items'].apply(lambda x: x['quantity'])
    df_items['item_revenue'] = df_items['items'].apply(lambda x: x['item_total'])

    # --- 1. Daily Sales Line Chart ---
    daily_sales = df_orders.groupby('date')['final_amount'].sum().reset_index()
    daily_sales['date_str'] = daily_sales['date'].dt.strftime('%Y-%m-%d')

    daily_fig = px.line(
        daily_sales, x='date_str', y='final_amount',
        title='💸 Daily Revenue Trend',
        labels={'final_amount': 'Total Revenue (₹)', 'date_str': 'Date'},
        line_shape='linear',
        color_discrete_sequence=['#FF6347']
    )
    peak_date_str = daily_sales.loc[daily_sales['final_amount'].idxmax(), 'date_str'] if not daily_sales.empty else "N/A"
    peak_revenue = daily_sales['final_amount'].max() if not daily_sales.empty else 0


    # --- 2. Top 5 Most Purchased Items (Bar Chart) ---
    item_sales = df_items.groupby('item_name')['quantity'].sum().nlargest(5).reset_index()
    item_sales.rename(columns={'quantity': 'Total Quantity Sold'}, inplace=True)
    item_fig = px.bar(
        item_sales, x='item_name', y='Total Quantity Sold',
        title='⭐ Top 5 Most Popular Items',
        labels={'item_name': 'Item'},
        color='Total Quantity Sold',
        color_continuous_scale=px.colors.sequential.Sunset
    )

    # --- 3. Sales by Category (Pie Chart) ---
    category_map = {item['name']: cat for cat, items in MENU_DATA.items() for item in items}
    df_items['category'] = df_items['item_name'].map(category_map).fillna('Other')

    category_revenue = df_items.groupby('category')['item_revenue'].sum().reset_index()
    category_fig = px.pie(
        category_revenue, names='category', values='item_revenue',
        title='📦 Revenue by Category',
        color_discrete_sequence=px.colors.qualitative.Dark24
    )
    category_fig.update_traces(textinfo='percent+label')

    # --- Key Metrics JSON Output ---
    total_revenue = df_orders['final_amount'].sum()
    total_orders = len(df_orders)

    key_metrics = {
        "Total Revenue (All Time)": f"₹{total_revenue:,.2f}",
        "Total Orders (All Time)": total_orders,
        "Peak Revenue Day": f"{peak_date_str} (₹{peak_revenue:,.2f})",
        "Most Sold Item": item_sales['item_name'].iloc[0] if not item_sales.empty else "N/A"
    }

    return daily_fig, item_fig, category_fig, key_metrics

def load_owner_dashboard():
    all_orders = []
    try:
        if os.path.exists(ALL_ORDERS_FILE) and os.path.getsize(ALL_ORDERS_FILE) > 0:
            with open(ALL_ORDERS_FILE, "r", encoding='utf-8') as f:
                all_orders = json.load(f)
    except: all_orders = []

    menu_stock_html = generate_menu_display(is_owner=True)
    daily_chart, top_items_chart, category_pie, key_metrics = generate_analytics_charts(all_orders)

    return menu_stock_html, daily_chart, top_items_chart, category_pie, key_metrics

def conditional_dashboard_load(is_owner):
    if is_owner:
        menu_html, daily_chart, top_items_chart, category_pie, key_metrics = load_owner_dashboard()
        return menu_html, daily_chart, top_items_chart, category_pie, key_metrics, gr.update(visible=False, value={}), gr.update(visible=False, value={})
    else:
        return gr.update(), gr.update(), gr.update(), gr.update(), gr.update(), gr.update(visible=False), gr.update(visible=False)

def switch_login_mode(mode):
    if mode == 'login':
        return gr.update(visible=True), gr.update(visible=False), "Login to your existing account."
    else:
        return gr.update(visible=False), gr.update(visible=True), "Register a new customer account to start ordering!"

# NEW: Sign-up handler - MODIFIED
def handle_signup(username, password):
    global CUSTOMER_CREDENTIALS

    if not username or not password:
        return "❌ Please enter both a username and password.", gr.update(visible=False), gr.update(visible=True)

    if username == OWNER_USER:
        return f"❌ Username '{username}' is reserved for the Owner.", gr.update(visible=False), gr.update(visible=True)

    if username in CUSTOMER_CREDENTIALS:
        # User already exists, switch to login
        return f"❌ Username '{username}' already exists. Please log in.", gr.update(visible=True), gr.update(visible=False)

    # Store the new user credentials (in-memory for this demo)
    CUSTOMER_CREDENTIALS[username] = password

    # Successful signup, switch back to login screen with success message
    return f"✅ Registration successful for '{username}'! Please log in.", gr.update(visible=True), gr.update(visible=False)


# MODIFIED: Login handler to check dynamic credentials and validate for non-owners - SECURE ENHANCEMENT
def handle_login(username, password, title_image, signup_btn_active):
    is_owner = (username == OWNER_USER and password == OWNER_PASS)
    is_registered_customer = (username in CUSTOMER_CREDENTIALS and CUSTOMER_CREDENTIALS.get(username) == password)

    # 1. Successful Owner Login
    if is_owner:
        msg = f"🎉 Welcome, {username}! Redirecting to Owner Dashboard."
        return gr.update(visible=False), gr.update(visible=False), gr.update(visible=True), msg, True, gr.update(visible=False), gr.update(visible=True), gr.update(visible=False), gr.update(elem_classes="") # Reset signup button class
    
    # 2. Successful Customer Login
    elif is_registered_customer:
        msg = f"🎉 Welcome, {username}! Ready to take your order."
        return gr.update(visible=False), gr.update(visible=False), gr.update(visible=True), msg, False, gr.update(visible=True), gr.update(visible=False), gr.update(visible=False), gr.update(elem_classes="") # Reset signup button class

    # 3. Failed Login - User not found (and not the owner)
    elif username and username not in CUSTOMER_CREDENTIALS and username != OWNER_USER:
        msg = f"❌ User **'{username}'** not found. Please **Sign-up**."
        # Keep logged_out_container, make login_screen visible, but switch to signup form
        # Also update the toggle buttons to show 'Sign-up' as active
        return gr.update(visible=True), gr.update(visible=True), gr.update(visible=False), msg, False, gr.update(visible=False), gr.update(visible=False), gr.update(visible=True), gr.update(elem_classes="active")

    # 4. Failed Login - Incorrect credentials (or empty fields)
    else:
        msg = "❌ Invalid Username or Password. Please try again."
        # Remain on login form
        return gr.update(visible=True), gr.update(visible=True), gr.update(visible=False), msg, False, gr.update(visible=True), gr.update(visible=False), gr.update(visible=False), gr.update(elem_classes="")


def handle_logout():
    order_manager.current_order = []
    order_manager.current_invoice_data = None

    return (
        gr.update(visible=True),
        gr.update(visible=True),
        gr.update(visible=False),
        gr.update(visible=False),
        gr.update(visible=False),
        'English (en)',
        generate_menu_display(is_owner=False),
        order_manager.get_current_order_summary(),
        gr.update(value=[]),
        "🚀 System Ready!",
        None,
        gr.update(value="<div style='text-align: center; padding: 50px; color: #666;'><h3>Invoice details will appear here.</h3></div>"),
        False,
        gr.update(elem_classes="active"),
        gr.update(elem_classes=""),
        gr.update(value=""),
        gr.update(visible=True),
        gr.update(visible=True), # login_form visible
        gr.update(visible=False), # signup_form hidden
        gr.update("Login to your existing account.") # reset login message
    )

# --- MODIFIED voice_chat_interface (Fully translated) ---
def voice_chat_interface(audio_input, chat_history, selected_language):
    chat_history = chat_history or []
    lang_info = LANG_MAP.get(selected_language, LANG_MAP['English (en)'])
    lang_code = lang_info['code']
    lang_display = lang_info['display']

    yield chat_history, None, order_manager.get_current_order_summary(), f"🎤 Processing voice in {lang_display}...", gr.update(visible=True), gr.update(visible=False), selected_language

    user_text = speech_to_text(audio_input, language_key=selected_language)
    if not user_text.strip():
        yield chat_history, None, order_manager.get_current_order_summary(), get_translated_text("❌ No speech detected. Please try again.", lang_code, lang_display), gr.update(visible=True), gr.update(visible=False), selected_language
        return

    display_user_text = get_translated_text(user_text, lang_code, lang_display)
    chat_history.append({"role": "user", "content": display_user_text})

    yield chat_history, None, order_manager.get_current_order_summary(), get_translated_text("🤔 Getting response from Gemini...", lang_code, lang_display), gr.update(visible=True), gr.update(visible=False), selected_language

    current_order_prompt = [{"name": item['name'], "quantity": item['quantity']} for item in order_manager.current_order]

    # --- NLU CALL with Multi-item Support ---
    gemini_response = gemini_chat(user_text, current_order_prompt, selected_language)

    if 'suggest' in gemini_response.lower() and not gemini_response.startswith('faq_answer'):
          gemini_response = suggest_best_seller(selected_language)

    bot_response_text_base, pdf_file, html_preview, response_lang_code, response_lang_display = process_gemini_commands(gemini_response, order_manager)

    final_bot_text = bot_response_text_base

    chat_history.append({"role": "assistant", "content": final_bot_text})

    audio_response_file = text_to_speech(final_bot_text, response_lang_code)
    status_msg = f"✅ Ready! (Spoken: {response_lang_display})"

    if 'finalize' in gemini_response.lower() and order_manager.current_invoice_data:
        confirm_summary_update = order_manager.get_current_order_summary()
        yield chat_history, audio_response_file, confirm_summary_update, status_msg, gr.update(visible=False), gr.update(visible=True), selected_language
    else:
        yield chat_history, audio_response_file, order_manager.get_current_order_summary(), status_msg, gr.update(visible=True), gr.update(visible=False), selected_language


def handle_pay_now_button(chat_history, selected_language):
    chat_history = chat_history or []
    lang_info = LANG_MAP.get(selected_language, LANG_MAP['English (en)'])
    lang_code = lang_info['code']
    lang_display = lang_info['display']
    response, summary, pdf, html_preview = order_manager.finalize_order()

    translated_response = get_translated_text(response, lang_code, lang_display)

    if not order_manager.current_invoice_data:
        chat_history.append({"role": "assistant", "content": translated_response})
        audio_file = text_to_speech(translated_response, lang_code)
        return chat_history, audio_file, summary, get_translated_text("❌ Order is empty!", lang_code, lang_display), gr.update(visible=True), gr.update(visible=False), selected_language

    chat_history.append({"role": "assistant", "content": get_translated_text("Redirecting to confirmation page...", lang_code, lang_display)})
    audio_file = text_to_speech(get_translated_text("Please confirm your order.", lang_code, lang_display), lang_code)
    return chat_history, audio_file, summary, get_translated_text("➡️ Please Confirm Your Order", lang_code, lang_display), gr.update(visible=False), gr.update(visible=True), selected_language

def handle_confirm_order(selected_language):
    if not order_manager.current_invoice_data:
        return "Error: No data to confirm. Starting new order.", None, gr.update(visible=False), gr.update(visible=False), None, None, gr.update(value=[]), gr.update(value=order_manager.get_current_order_summary())

    order_manager.print_and_store_json()
    pdf_file = order_manager.generate_invoice_pdf()
    html_preview = order_manager.generate_invoice_html_preview()

    lang_info = LANG_MAP.get(selected_language, LANG_MAP['English (en)'])
    lang_code = lang_info['code']
    lang_display = lang_info['display']

    english_final_response_text = f"Thank you! Your order number is {order_manager.current_invoice_data['invoice_number']}."
    final_response_text = get_translated_text(english_final_response_text, lang_code, lang_display)

    audio_file = text_to_speech(final_response_text, lang_code)

    return (
        get_translated_text("✅ Order Confirmed! Invoice Ready.", lang_code, lang_display), audio_file, gr.update(visible=False), gr.update(visible=True),
        pdf_file, html_preview, gr.update(value=[]), gr.update(value=order_manager.get_current_order_summary())
    )

def handle_back_from_confirm():
    return gr.update(visible=True), gr.update(visible=False)

def clear_chat():
    order_manager.current_order = []
    return [], order_manager.get_current_order_summary()

def handle_sales_analysis(start_date, end_date):
    return order_manager.get_sales_analysis(start_date, end_date), gr.update(visible=True)

def handle_daily_report():
    today = datetime.now().strftime('%Y-%m-%d')
    return order_manager.generate_daily_report(today), gr.update(visible=True)

def handle_file_info():
    info = {
        "ALL_ORDERS_FILE": ALL_ORDERS_FILE,
        "DAILY_REPORTS_DIR": DAILY_REPORTS_DIR,
        "All Orders File Exists": os.path.exists(ALL_ORDERS_FILE),
        "All Orders File Size (Bytes)": os.path.getsize(ALL_ORDERS_FILE) if os.path.exists(ALL_ORDERS_FILE) else 0,
        "Daily Reports Directory Exists": os.path.exists(DAILY_REPORTS_DIR),
        "Daily Reports Count": len([f for f in os.listdir(DAILY_REPORTS_DIR) if os.path.isfile(os.path.join(DAILY_REPORTS_DIR, f))]) if os.path.exists(DAILY_REPORTS_DIR) else 0,
    }
    return info, gr.update(visible=True)

def handle_blockchain_audit():
    return display_chain_data(), gr.update(visible=True)

def handle_language_change(selected_language):
    return selected_language

def start_new_order_from_invoice(is_owner):
    order_manager.current_order = []
    order_manager.current_invoice_data = None

    target_main_interface_visible = gr.update(visible=not is_owner)
    target_owner_dashboard_visible = gr.update(visible=is_owner)

    dashboard_updates = []
    if is_owner:
        _, daily_chart, top_items_chart, category_pie, key_metrics = load_owner_dashboard()
        dashboard_updates = [daily_chart, top_items_chart, category_pie, key_metrics]
    else:
        dashboard_updates = [gr.update(), gr.update(), gr.update(), gr.update()]

    return (
        target_main_interface_visible,
        target_owner_dashboard_visible,
        gr.update(visible=False),
        generate_menu_display(is_owner=is_owner),
        order_manager.get_current_order_summary(),
        gr.update(value=[]),
        "🚀 System Ready! Start a new order.",
        None,
        gr.update(value="<div style='text-align: center; padding: 50px; color: #666;'><h3>Invoice details will appear here.</h3></div>"),
        *dashboard_updates
    )


# --- CUSTOM CSS (Monochrome Theme with Color Accents) ---
custom_css = """
/* Main background with monochrome theme */
.gradio-container {
    background: #f0f0f0 !important; /* Light Grey background */
    font-family: 'Arial', sans-serif !important;
    min-height: 100vh;
    color: #333;
}
/* Login Screen Styling - Monochromatic */
.login-container {
    background: #fff !important;
    border-radius: 10px !important;
    border: 2px solid #333 !important;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2) !important;
    padding: 30px !important;
    max-width: 400px !important;
    margin: 30px auto !important;
    text-align: center;
}
/* Card styling with a sharp, modern monochrome look */
.gr-box, .gr-form, .gr-panel {
    background: #fff !important;
    border-radius: 8px !important;
    border: 1px solid #ccc !important;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05) !important;
}
/* Chatbot styling */
.gr-chatbot {
    background: #f9f9f9 !important;
    border-radius: 8px !important;
    border: 1px solid #ccc !important;
}
/* Button styling - Black and White (Primary) */
.gr-button {
    background: #333 !important;
    color: white !important;
    border-radius: 5px !important;
    font-weight: 600 !important;
    border: none !important;
}
/* Secondary buttons light/grey */
.gr-button.secondary {
    background: #ccc !important;
    color: #333 !important;
}
.gr-button:hover {
    transform: translateY(-1px) !important;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2) !important;
}
/* Voice interface section */
.voice-section {
    background: #e8e8e8 !important;
    border-radius: 8px !important;
    border: 1px solid #aaa !important;
    padding: 15px !important;
    margin: 10px 0 !important;
}
/* Invoice preview styling */
.invoice-preview {
    background: white !important;
    border-radius: 10px !important;
    border: 2px solid #333 !important;
    padding: 20px !important;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1) !important;
}

/* Custom CSS for the Menu Column to resemble a sidebar menu */
.menu-column {
    min-width: 300px;
    padding: 15px;
}
/* NEW CSS: Added a dedicated class for the scrollable content */
.menu-scroll-content {
    max-height: 70vh;
    overflow-y: auto;
    padding-right: 15px;
}
/* Header bar for Login/Sign-up */
.header-bar {
    background-color: #333;
    color: white;
    padding: 10px 20px;
    margin-bottom: 20px;
    border-radius: 5px;
}

/* FIX: Custom class for the title in the header */
.header-title h1 {
    font-size: 2em;
    margin: 0;
    color: white;
}
/* Intro text styling */
.intro-text-center p {
    text-align: center;
    margin-bottom: 10px;
}

.header-button-group .gr-button {
    background: none !important;
    border: 1px solid white !important;
    color: white !important;
    margin-left: 10px;
}
.header-button-group .gr-button.active {
    background: white !important;
    color: #333 !important;
    font-weight: bold;
}
/* FIX: Ensure the title image fills the horizontal space */
.title-image-container {
    max-width: 500% !important;
    width: 100% !important;
    height: auto !important;
    background-color: #000 !important;
}

/* Ensure the image element inside the Gradio component also fills its container */
.title-image-container img {
    width: 500% !important;
    height: auto !important;
    object-fit: cover !important;
}
/* Owner Dashboard Analytics Specific Styling (Colorful Accents) */
.gr-plot {
    border: 1px solid #ddd !important;
    border-radius: 8px !important;
    background: #fff !important;
    padding: 10px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}
.gradio-json {
    background-color: #e6f7ff !important; /* Light blue background for KPIs */
    border: 1px solid #91d5ff !important;
    padding: 10px;
    border-radius: 8px;
}
"""

# --- GRADIO INTERFACE DEFINITION ---

with gr.Blocks(theme=gr.themes.Soft(), css=custom_css, title="Talk2Invoice Restaurant") as app:
    is_owner_state = gr.State(value=False)
    login_mode_state = gr.State(value='login')

    status_box = gr.Textbox("🚀 System Ready! Loading models...", label="System Status", max_lines=2, interactive=False)

    # --- LOGGED-OUT CONTAINER: Contains the Header and Intro/Login Screens ---
    logged_out_container = gr.Group(visible=True)
    with logged_out_container:
        # --- TOP LEVEL TOGGLE (Header) ---
        with gr.Row(elem_classes="header-bar"):
            gr.Markdown("# 🍽 Talk2Invoice Restaurant", elem_classes="header-title")
            with gr.Row(scale=1, elem_classes="header-button-group"):
                login_toggle_btn = gr.Button("Login", variant="primary", elem_classes="active")
                signup_toggle_btn = gr.Button("Sign-up", variant="secondary")

        # 1. Intro Page (visible first)
        intro_page = gr.Group(visible=True)
        with intro_page:
            title_image = gr.Image(
                value=TITLE_IMAGE_PATH,
                label="Talk2Invoice: Effortless Ordering",
                show_label=False,
                interactive=False,
                elem_classes="title-image-container"
            )
            with gr.Column(elem_classes="intro-text-center"):

                gr.Markdown(
                    "Use the **Login/Sign-up** buttons above to get started.\n\n"
                    "**Owner Demo:** Use *admin/owner123*\n"
                    "**Customer Demo:** Please **Sign-up** for a new account to set your credentials, then **Login**."
                )

        # 2. Login/Sign-up Screen
        login_screen = gr.Group(visible=False)
        with login_screen:
            login_message = gr.Markdown("Login to your existing account.", elem_classes="intro-text-center")
            with gr.Column(elem_classes="login-container"):
                login_form = gr.Group(visible=True)
                with login_form:
                    username = gr.Textbox(label="👤 Username", placeholder="customer / admin")
                    password = gr.Textbox(label="🔒 Password", type="password", placeholder="your_password / owner123")
                    login_btn = gr.Button("🚀 Login to Restaurant System", variant="primary")

                signup_form = gr.Group(visible=False)
                with signup_form:
                    new_username = gr.Textbox(label="👤 New Username", placeholder="new_customer")
                    new_password = gr.Textbox(label="🔒 New Password", type="password", placeholder="set_your_password")
                    signup_btn = gr.Button("✅ Register & Go to Login", variant="secondary")

    # --- MAIN APPLICATION CONTAINER: Visible only when logged in ---
    main_application = gr.Group(visible=False)
    with main_application:

        # --- OWNER DASHBOARD ---
        owner_dashboard = gr.Group(visible=False)
        with owner_dashboard:
            gr.Markdown("## 👑 Owner Dashboard: Menu & Advanced Analytics")
            with gr.Row():
                with gr.Column(scale=1, elem_classes="menu-column"):
                    gr.Markdown("### 📋 Menu Stock Status")
                    owner_menu_display = gr.HTML(generate_menu_display(is_owner=True))

                with gr.Column(scale=2):
                    gr.Markdown("### 📊 Business Analytics")

                    key_metrics_json = gr.JSON(label="🔑 Key Performance Indicators (KPIs)", visible=True)

                    with gr.Row():
                        daily_sales_chart = gr.Plot(label="Daily Revenue Trend")
                        top_items_chart = gr.Plot(label="Top 5 Most Popular Items")

                    with gr.Row():
                        category_pie_chart = gr.Plot(label="Revenue by Category")

                    with gr.Accordion("Report Generation Tools", open=False):
                        with gr.Row():
                            start_date = gr.Textbox(label="Start Date (YYYY-MM-DD)", placeholder="e.g., 2024-01-01")
                            end_date = gr.Textbox(label="End Date (YYYY-MM-DD)", placeholder="e.g., 2024-01-31")
                        with gr.Row():
                            analyze_btn = gr.Button("📈 Analyze Sales Performance (Range)", variant="primary")
                            daily_report_btn = gr.Button("📅 Generate Today's Report", variant="secondary")
                            file_info_btn = gr.Button("📁 File Info", variant="secondary")
                        analysis_output = gr.JSON(label="Analytics Results (JSON Output)", visible=False)

                    with gr.Accordion("Blockchain Stock & Queue Control", open=True):
                        gr.Markdown("#### Real-time Stock Management (Simulated Ledger)")
                        with gr.Row():
                            all_menu_names = [item['name'] for cat in MENU_DATA.values() for item in cat]
                            item_to_toggle = gr.Dropdown(label="Item to Update", choices=all_menu_names)
                            stock_status_toggle = gr.Radio(label="New Status", choices=['In Stock', 'Out of Stock'], value='In Stock')
                        stock_update_btn = gr.Button("🔄 Update Stock on Ledger", variant="primary")

                        gr.Markdown("#### Ledger Audit")
                        audit_chain_btn = gr.Button("🔍 Audit Blockchain State", variant="secondary")
                        blockchain_status = gr.JSON(label="Simulated Ledger Status", visible=False)

                    owner_logout_btn = gr.Button("⬅ Logout", variant="secondary", size="lg")


        # --- CUSTOMER ORDERING INTERFACE (main_interface) ---
        main_interface = gr.Group(visible=True)
        with main_interface:
            with gr.Row():
                with gr.Column(scale=1, elem_classes="menu-column"):
                    gr.Markdown("## 📋 Menu")
                    menu_display = gr.HTML(generate_menu_display(is_owner=False))

                with gr.Column(scale=2):
                    with gr.Row():
                        language_dropdown = gr.Dropdown(
                            label="🌐 Select Language", choices=list(LANG_MAP.keys()), value='English (en)', interactive=True, container=True
                        )
                        customer_logout_btn = gr.Button("Logout", variant="secondary", size="sm")

                    with gr.Row():
                        chatbot = gr.Chatbot(label="💬 Conversation", height=250, layout="bubble")
                        order_summary_display = gr.Markdown(order_manager.get_current_order_summary(), label="🛒 Current Order")

                    with gr.Row(elem_classes="voice-section"):
                        with gr.Column(scale=1):
                            gr.Markdown("### 👂 Customer Voice")
                            audio_in = gr.Audio(sources=["microphone"], type="filepath", label="Click & Hold to Speak", interactive=True)
                        with gr.Column(scale=1):
                            gr.Markdown("### 🗣 Waiter Voice")
                            audio_out = gr.Audio(label="AI Waiter Response", autoplay=True, interactive=False)

                    with gr.Row():
                        pay_button = gr.Button("🧾 Finalize Order", variant="primary", size="lg")
                        clear_btn = gr.Button("🗑 Clear Order", variant="secondary", size="lg")

        # --- CONFIRMATION PAGE ---
        confirmation_interface = gr.Group(visible=False)
        with confirmation_interface:
            gr.Markdown("## 🔒 Confirm Your Order")
            confirm_summary = gr.Markdown(order_manager.get_current_order_summary(), label="Final Cart Summary")
            with gr.Row():
                confirm_btn = gr.Button("✅ Confirm & Proceed to Invoice", variant="primary", size="lg")
                back_to_order_btn = gr.Button("⬅ Back to Ordering", variant="secondary", size="lg")
            confirm_status_box = gr.Textbox("Awaiting confirmation...", label="Confirmation Status", interactive=False)

        # --- INVOICE PREVIEW INTERFACE ---
        invoice_interface = gr.Group(visible=False)
        with invoice_interface:
            gr.Markdown("## 🧾 Order Confirmed! Receipt Preview & Download.")
            with gr.Tabs():
                with gr.TabItem("👀 HTML Preview"):
                    invoice_preview = gr.HTML(label="Invoice Preview", value="<div style='text-align: center; padding: 50px; color: #666;'><h3>Invoice details will appear here.</h3></div>", elem_classes="invoice-preview")
                with gr.TabItem("📄 PDF Download"):
                    invoice_file = gr.File(label="Invoice PDF", file_count="single", interactive=False, height=400, type="binary", file_types=["pdf"])
            back_btn_from_invoice = gr.Button("⬅ Start New Order", variant="secondary", size="lg")


    # --- EVENT HANDLERS ---

    # 0. Header Navigation Handlers
    def navigate_to_login(is_signup):
        # Always hide the intro page when navigating to login/signup
        # Always show the login/signup screen
        if is_signup:
            # Switch to signup form
            return gr.update(visible=False), gr.update(visible=True), gr.update(visible=False), gr.update(visible=True)
        else:
            # Switch to login form
            return gr.update(visible=False), gr.update(visible=True), gr.update(visible=True), gr.update(visible=False)


    login_toggle_btn.click(
        lambda: ['login', gr.update(elem_classes="active"), gr.update(elem_classes="")],
        None,
        [login_mode_state, login_toggle_btn, signup_toggle_btn]
    ).then(
        lambda: navigate_to_login(False), None, [intro_page, login_screen, login_form, signup_form]
    ).then(
        lambda: "Login to your existing account.", None, login_message
    )

    signup_toggle_btn.click(
        lambda: ['signup', gr.update(elem_classes=""), gr.update(elem_classes="active")],
        None,
        [login_mode_state, login_toggle_btn, signup_toggle_btn]
    ).then(
        lambda: navigate_to_login(True), None, [intro_page, login_screen, login_form, signup_form]
    ).then(
        lambda: "Register a new customer account to start ordering!", None, login_message
    )

    # NEW: Signup button logic
    signup_btn.click(
        handle_signup,
        [new_username, new_password],
        [login_message, login_form, signup_form]
    ).then(
        # On successful signup, ensure login button is marked as active
        lambda msg: [gr.update(elem_classes="active") if msg.startswith("✅") else gr.update(), gr.update(elem_classes="") if msg.startswith("✅") else gr.update()],
        [login_message], # Pass the message to conditionally update the buttons
        [login_toggle_btn, signup_toggle_btn]
    )


    # 1. Login Handler - MODIFIED
    owner_dashboard_outputs = [owner_menu_display, daily_sales_chart, top_items_chart, category_pie_chart, key_metrics_json, analysis_output, blockchain_status]

    login_btn.click(
        handle_login,
        [username, password, title_image, signup_toggle_btn], # Added signup_toggle_btn as input
        [logged_out_container, login_screen, main_application, status_box, is_owner_state, main_interface, owner_dashboard, title_image, signup_toggle_btn]
    ).then(
        # Handle the automatic switch to signup form on 'User not found' error
        lambda msg, is_owner: [gr.update(visible=True), gr.update(visible=False), gr.update(elem_classes="active"), gr.update(elem_classes="")],
        [status_box, is_owner_state],
        [login_form, signup_form, login_toggle_btn, signup_toggle_btn]
    ).then(
        conditional_dashboard_load,
        [is_owner_state],
        owner_dashboard_outputs
    ).then(
        lambda: gr.update(value="Logout"),
        None,
        customer_logout_btn
    )

    # 2. Customer Flow Handlers
    voice_chat_outputs = [chatbot, audio_out, order_summary_display, status_box, main_interface, confirmation_interface, language_dropdown]
    audio_in.change(
        fn=voice_chat_interface,
        inputs=[audio_in, chatbot, language_dropdown],
        outputs=voice_chat_outputs
    )

    pay_button.click(
        handle_pay_now_button,
        [chatbot, language_dropdown],
        [chatbot, audio_out, confirm_summary, status_box, main_interface, confirmation_interface, language_dropdown]
    )

    back_to_order_btn.click(
        handle_back_from_confirm,
        None,
        [main_interface, confirmation_interface]
    )

    confirm_btn.click(
        handle_confirm_order,
        [language_dropdown],
        [confirm_status_box, audio_out, confirmation_interface, invoice_interface,
         invoice_file, invoice_preview, chatbot, order_summary_display]
    )

    # 3. Navigation and Utility Handlers
    start_new_order_outputs = [
        main_interface, owner_dashboard, invoice_interface, menu_display, order_summary_display,
        chatbot, status_box, invoice_file, invoice_preview,
        daily_sales_chart, top_items_chart, category_pie_chart, key_metrics_json
    ]
    back_btn_from_invoice.click(
        start_new_order_from_invoice,
        [is_owner_state],
        start_new_order_outputs
    )

    logout_outputs = [
        logged_out_container, intro_page, main_application, confirmation_interface, invoice_interface,
        language_dropdown, menu_display, order_summary_display, chatbot, status_box, invoice_file, invoice_preview,
        is_owner_state, login_toggle_btn, signup_toggle_btn, customer_logout_btn, title_image, 
        login_form, signup_form, login_message # Added login/signup form controls
    ]
    customer_logout_btn.click(handle_logout, None, logout_outputs)
    owner_logout_btn.click(handle_logout, None, logout_outputs)


    clear_btn.click(clear_chat, outputs=[chatbot, order_summary_display])

    # 4. Analytics and Blockchain Event Handlers
    analyze_btn.click(
        handle_sales_analysis,
        [start_date, end_date],
        [analysis_output, analysis_output]
    )

    daily_report_btn.click(
        handle_daily_report,
        outputs=[analysis_output, analysis_output]
    )

    file_info_btn.click(
        handle_file_info,
        outputs=[analysis_output, analysis_output]
    )

    stock_update_btn.click(
        owner_update_stock,
        [item_to_toggle, stock_status_toggle],
        [status_box, owner_menu_display]
    )

    audit_chain_btn.click(
        handle_blockchain_audit,
        outputs=[blockchain_status, blockchain_status]
    )

    # Initial Model Load
    app.load(fn=load_model, outputs=status_box)

    # Language change handler
    language_dropdown.change(handle_language_change, inputs=[language_dropdown], outputs=[language_dropdown])

app.launch(debug=True, share=True)